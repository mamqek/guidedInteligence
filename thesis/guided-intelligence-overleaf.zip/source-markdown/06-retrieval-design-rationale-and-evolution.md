# Retrieval Design Rationale and Evolution

<!-- TODO design rationale: explain that Bloom's revised taxonomy was used only as a design-time coverage check across different cognitive activities when developing the intent taxonomy. It is not exposed in the system vocabulary or used as a runtime classification scheme. Cite the selected Bloom source if this rationale is retained in the chapter. -->

<!-- TODO CodeGraph evidence boundary: explain the experiments that attempted to use graph metadata more directly as evidence. Identify the relevant retained and rejected variants from the retrieval changelog, show how weak or noisy graph connections affected evidence quality, and explain why the final design requires every retained relationship to be supported by inspectable source. This is the place for the design history and resulting lesson; do not report the final ablation statistics here. -->
